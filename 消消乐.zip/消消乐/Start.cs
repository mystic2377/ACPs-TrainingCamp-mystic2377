﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace SuperPeng
{
    public partial class Start : Form
    {
        public Start()
        {
            InitializeComponent();
        }
        private GameField gameField;  //游戏场对象字段
        private bool first = true; //区分第一次跟第二次
        private Block firstBlock2 = null; //鼠标单击时选定的方块
        private Block secondBlock2 = null;
        //firstBlock为blocks数组中的[xx1,yy1],secondBlock为blocks数组中的[xx2,yy2]
        private int xx1, yy1, xx2, yy2;
        private int tempx, tempy;
        private int timeAll = 0;//时钟计时
        private int score = 0;//游戏积分
        private Sunisoft.IrisSkin.SkinEngine skin = new Sunisoft.IrisSkin.SkinEngine();

        private void Start_Load(object sender, EventArgs e)
        {
            GetSkin("0.ssk");     //换肤,0.ssk是皮肤文件
            gameField = new GameField();
            gameField.winHandle = pic_GameField.Handle;
            gameField.bufferImage = pic_GameField.BackgroundImage;

            //显示游戏开始画面
            pic_show.BringToFront();
            pic_show.Image = Properties.Resources.bg_start;
        }

        #region 事件……

        /*支持单击移动*/
        private void pic_GameField_MouseClick(object sender, MouseEventArgs e)
        {
            if (first)
            {
                firstBlock2 = analyse(e.X, e.Y);
                xx1 = tempx;
                yy1 = tempy;
                if (firstBlock2 != null)
                {
                    first = false;
                    firstBlock2.DrawSelectedBlock(pic_GameField.CreateGraphics());
                }
            }
            else
            {
                secondBlock2 = analyse(e.X, e.Y);
                xx2 = tempx;
                yy2 = tempy;
                if (secondBlock2 == null || firstBlock2.Location == secondBlock2.Location
                   ||Math.Abs(firstBlock2.Location.X - secondBlock2.Location.X) > 50 
                   ||Math.Abs(firstBlock2.Location.Y - secondBlock2.Location.Y) > 50 
                   || (Math.Abs(firstBlock2.Location.X - secondBlock2.Location.X) == 50
                   && Math.Abs(firstBlock2.Location.Y - secondBlock2.Location.Y) == 50)
                   ) //选择第二个方块不相邻           
                {
                   return;
                }
                else
                {
                    first = true;
                    secondBlock2.DrawSelectedBlock(pic_GameField.CreateGraphics());
                }
                //可以交换时交换并检测
                gameField.exchange(xx1, yy1, xx2, yy2);
                bool cando = false;
                int numb;
                int k;
                while ((numb = gameField.check()) != 0)
                {
                    cando = true;
                    score += numb;
                    k=myProcessbar1.Value + (int)Math.Floor((double)numb / 2);
                    myProcessbar1.Value = (k <= 100) ? k : 100;
                    gameField.fill();
                    Thread.Sleep(500); //等待一下
                }
                if (!cando)
                {//撤销本次交换 
                    gameField.exchange(xx1, yy1, xx2, yy2);
                }
                first = true;
            }
        }
        /*声音开关*/
        private void pic_sound_Click(object sender, EventArgs e)
        {
            gameField.soundSwitch = !gameField.soundSwitch;
            if (gameField.soundSwitch)
                pic_sound.Image = Properties.Resources.sound;
            else
                pic_sound.Image = Properties.Resources.nosound;
        }
        /*在开始或结束画面上按鼠标：游戏重新开始*/
        private void pic_show_MouseUp(object sender, MouseEventArgs e)
        {
            if (164 < e.X&&e.X< 330 && 400 < e.Y&& e.Y< 456)
            {
                //先判断是否点击在按钮上面
                score = 0;
                myProcessbar1.Value = 100;
                timer1.Start();
                pic_show.SendToBack();
                reStart();
                用剩下一半的生命招呼一次刷新ToolStripMenuItem.Enabled = true;
            }

        }
        /*游戏时钟*/
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (myProcessbar1.Value > 0)
                myProcessbar1.Value--;
            else
                gameover();

            //5分钟刷新一次
            if (timeAll < 300)
                timeAll += 2;
            else
            {
                reStart();
                timeAll = 0;
            }
        }

        /*左键弹出菜单*/
        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
                contextMenuStrip1.Show(button1, new Point(button1.Width, button1.Height));
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Help he = new Help();
            he.Show();
        }
        /*菜单*/
        private void 用剩下一半的生命招呼一次刷新ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer1.Stop(); //保证生命值更改同步
            myProcessbar1.Value = (int)Math.Floor((double)myProcessbar1.Value / 2);
            reStart();
            timer1.Start();
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help he = new Help();
            he.Show();
        }
        #endregion

        #region 方法……

        /*全部重新开始*/
        public void reStart()
        {
            gameField.createAll();
            while (gameField.check() != 0)
            {
                gameField.fill();
                Thread.Sleep(500); //等待一下
            }
        }

        /*解析鼠标之下的方块对象*/
        private Block analyse(int x, int y)
        {
            tempx = (int)Math.Floor((double)y / 50);
            tempy = (int)Math.Floor((double)x / 50);
            //防止超出范围
            if (tempx > 9 || tempy > 9 || tempx < 0 || tempy < 0)
                return null;
            else
                return gameField.blocks[tempx, tempy];
        }

        /*处理游戏结束事件*/
        public void gameover()
        {
            timer1.Stop();
            Image tempimg = Properties.Resources.bg_end;
            Graphics g = Graphics.FromImage(tempimg);
            g.DrawString(score.ToString(), new Font("Arial", 36, FontStyle.Bold),
                new SolidBrush(Color.Yellow), new Point(238, 240));
            pic_show.Image = tempimg;
            pic_show.BringToFront();
            用剩下一半的生命招呼一次刷新ToolStripMenuItem.Enabled = false;
        }

        #endregion
        /// <summary>
        /// 皮肤
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <summary>
        /// 皮肤
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tsmi = (ToolStripMenuItem)sender;
            int index = Convert.ToInt32(tsmi.Tag);

            string skinname = "";

            switch (index)
            {
                case 0:
                    skinname = "0.ssk";
                    break;
                case 1:
                    skinname = "1.ssk";
                    break;
                case 2:
                    skinname = "2.ssk";
                    break;
                case 3:
                    skinname = "3.ssk";
                    break;
                case 4:
                    skinname = "4.ssk";
                    break;
                case 5:
                    skinname = "5.ssk";
                    break;
                case 6:
                    skinname = "6.ssk";
                    break;
                case 7:
                    skinname = "7.ssk";
                    break;
                case 8:
                    skinname = "8.ssk";
                    break;
                case 9:
                    skinname = "9.ssk";
                    break;
                default:
                    skinname = "";
                    break;
            }
            GetSkin(skinname);
        }
        //换肤
        private void GetSkin(string skinName)
        {
            skin.SkinFile = Application.StartupPath + @"\skin\" + skinName;// @"\skin\0.ssk"; //0.ssk是皮肤文件 
            skin.Active = true;
            skin.SkinAllForm = true;
        }
    }
}