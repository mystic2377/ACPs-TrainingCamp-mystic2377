﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Threading;
using System.Media;
using SuperPeng.Properties;

namespace SuperPeng
{
    /*
     * 场景大小：500×500
     * 方块大小：50×50
     */
    class GameField
    {
        public  IntPtr winHandle;
        public  Image bufferImage;  //双缓存
        public  Block[,] blocks=new Block[10,10]; //场景中所有的小图片
        //存储绘制的方块图案带代号的数组，不需绘制的值为0
        private int[,] rectan2 = new int[10, 10];
        private int[] empty = new int[10];//每列有多少个可以消去方块
        private int RowSames = 1; //检测到同行相同数
        private int ColumSames = 1; //检测到同列相同数
        private SoundPlayer sound = new SoundPlayer();
        public  bool soundSwitch = true;//声音开关   true为开

        /*生成场景中所有的对象*/
        public void createAll()
        {
            Random rand = new Random();
            for (int i = 0; i < 10; i++)
                for (int j = 0; j < 10; j++)
                {
                    Block b = new Block(rand.Next(8) + 1, j * 50, i * 50);
                    blocks[i, j] = b;
                    //rectan[i,j] = b.ImageType;//******************7-06
                    rectan2[i, j] = b.ImageType;
                }
            reDraw();
        }

        /*交换两个方块，参数x，y为矩阵坐标*/
        public void exchange(int x1, int y1, int x2, int y2)
        {
            //交换blocks
            Block temp = blocks[x1, y1];
            blocks[x1, y1] = blocks[x2, y2];
            blocks[x2, y2] = temp;

            ////交换rectan  //******************7-06
            //rectan[x1, y1] = blocks[x1, y1].ImageType;
            //rectan[x2, y2] = blocks[x2, y2].ImageType;

            //交换rectan2
            rectan2[x1, y1] = blocks[x1, y1].ImageType;
            rectan2[x2, y2] = blocks[x2, y2].ImageType;

            //交换坐标
            Point tmploc = blocks[x1, y1].Location;
            blocks[x1, y1].Location = blocks[x2, y2].Location;
            blocks[x2, y2].Location = tmploc;

            PlaySound("Exchange");
            //重画一下
            reDraw();

        }
        /*对对碰检测，返回可以消除方块对象的个数*/
        public  int check()
        {
            //检测是否同行或列有超过3个一样
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    //for内开始
                    //行检测
                    if (j == 0)
                        RowSames = 1;
                    else
                    {
                        if (blocks[i, j - 1].ImageType == blocks[i, j].ImageType)//图案相同
                            RowSames++;
                        else
                        {
                            if (RowSames >= 3)
                            {
                                //该位置之前rowsames个格子的物体都要消除
                                for (int n = 1; n <= RowSames; n++)
                                    rectan2[i, j - n] = 0;
                            }
                            RowSames = 1;
                        }
                        if (j==9&&RowSames >= 3)
                        {
                            //该位置之前rowsames个格子的物体都要消除
                            for (int n = 1; n <= RowSames; n++)
                                rectan2[i, 10 - n] = 0;
                        }
                    }
                    
                   
                    //列检测
                    if (j == 0)
                        ColumSames = 1;
                    else
                    {
                        if (blocks[j - 1, i].ImageType == blocks[j, i].ImageType)//图案相同
                            ColumSames++;
                        else
                        {
                            if (ColumSames >= 3)
                            {
                                //该位置之上的columsames个格子的物体要消除
                                for (int n = 1; n <= ColumSames; n++)
                                    rectan2[j - n, i] = 0;
                            }
                            ColumSames = 1;
                        }
                        if (j==9&&ColumSames >= 3)
                        {
                            //该位置之前rowsames个格子的物体都要消除
                            for (int n = 1; n <= ColumSames; n++)
                                rectan2[10 - n, i] = 0;
                        }
                    }
                    //for内结束
                }
            }
            RowSames = 1;
            ColumSames = 1;
            //检测每列有多少个空格
            int temp=0;
            int result = 0;//总和
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (rectan2[j, i] == 0)
                        temp++;
                }
                empty[i] = temp;
                result += temp;
                temp = 0;
            }
            //reDraw();
            return result;
        }

        /*生成填补*/
        public  void fill() 
        {
            Random rand = new Random();
            for (int j = 0; j < 10;j++ ) //每列
            {
                if(empty[j] > 0)
                {
                    for (int i = 0; i < 10; i++) //每行
                    {
                        while(rectan2[i, j] == 0)
                        {
                            if (i >0)
                            {//空格之后的所有图片向下移一位
                                for (int n = i-1; n>=0; n--)
                                    down(n,j);
                            }
                            //填充最顶上一格方块
                            Block tb = new Block(rand.Next(8) + 1, j * 50,0 );
                            blocks[0, j] = tb;
                            //rectan[0, j] = tb.ImageType;
                            rectan2[0, j] = tb.ImageType;
                        }
                    }
                   //本来想在这里重画，不料令游戏速度太慢
                }
            }
            PlaySound("AddScore");
            //重画一下
            reDraw();
        }

        /*下移某方块对象，参数x，y为矩阵坐标*/
        public  void down(int x, int y)//7-7 add
        {
            if (x<9)
            {
                //方块下移50像素
                //blocks[x, y].Location.Y += 50;
                int px = blocks[x, y].Location.X;
                int py = blocks[x, y].Location.Y ;
                blocks[x, y].Location = new Point(px, py + 50);
                blocks[x+1, y ] = blocks[x, y];
                //rectan[x+1, y ] = rectan[x, y];//******************7-06
                rectan2[x+1, y ] = rectan2[x, y];
            }
        }



        /*播放声音*/
        public  void PlaySound(string soundstr)
        {
            if (!soundSwitch)
                return;
            if (sound.Stream != null) //声音同步
                return;
            switch (soundstr)
            {
                case "AddScore": //消除一片的声音
                    sound.Stream = Resources.folder;
                    break;
                case "Exchange": //交换方块的声音
                    sound.Stream = Resources.exchange;
                    break;
            }
            sound.Play();
            sound.Stream = null;
        }

        /*重画场景中所有对象*/
        public  void reDraw()
        {
            //重画背景
            Graphics g = Graphics.FromImage(bufferImage);
            Bitmap bg =SuperPeng.Properties.Resources.bg_GameField;
            g.DrawImage(bg,0,0,500,500);
            //画物体
            for (int i = 0; i < 10; i++)
                for (int j = 0; j < 10; j++)
                {
                    if (rectan2[i, j] != 0)
                        blocks[i, j].Draw(bufferImage);
                }
            //缓存输出
            Graphics g2 = Graphics.FromHwnd(winHandle);
            g2.DrawImage(bufferImage,0, 0, 500, 500);
        }
    }
}
