﻿

using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace SuperPeng
{
    public partial class Help : Form
    {
        public Help()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("iexplore.exe", "http://289009477.qq.com");
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}